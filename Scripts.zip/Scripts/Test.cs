﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        string infos = Resources.Load<TextAsset>("Json/EquipInfo").text;
        Debug.Log(infos.ToString());
        EquipInfos info = JsonUtility.FromJson<EquipInfos>(infos);
        Debug.Log(info.info.Count);
        Debug.Log(info.info[0].Name);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
