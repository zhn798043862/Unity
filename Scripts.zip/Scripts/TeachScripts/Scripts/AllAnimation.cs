﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface  AllAnimation 
{
    void PlayerAttack();
    void Move(float a,float b);
    void StandAndRelax();
}
