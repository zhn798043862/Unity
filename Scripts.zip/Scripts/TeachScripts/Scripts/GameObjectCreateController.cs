﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameObjectCreateController : MonoBehaviour
{
    public static GameObjectCreateController instance;


    private void Start()
    {
        instance = this;
    }

    public GameObject AddGameObject(GameObject gameObject, Vector3 position)
    {

        GameObject jian = GameObjectPool.instance.GetPool(gameObject, position);
        return jian;
    }

    public void RemoveGameObject()
    {
        GameObjectPool.instance.IntoPool(gameObject);
    }
}
