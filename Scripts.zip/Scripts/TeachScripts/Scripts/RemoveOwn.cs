﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RemoveOwn : MonoBehaviour
{
    public static RemoveOwn instance;
    void Start()
    {
        instance = this;
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    public void Destroy()
    {
        EffectCreateController.instance.RemoveAttackEffect01();
    }
}
