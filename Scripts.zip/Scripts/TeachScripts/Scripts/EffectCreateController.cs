﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectCreateController :GameObjectCreateController
{
    public new static EffectCreateController instance;
    private static GameObject attackEffect01;
    private GameObject attckEffect;
    private static Transform jian;
    private void Start()
    {
        instance = this;

        attackEffect01 = Resources.Load<GameObject>("SpecialEffects/OrdosFX/Magic Slashes FX/Prefabs/EffectPrefabs/Eff1_Left");

        jian = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    
    public GameObject AddAttackEffect01()
    {

        attckEffect = Pool.instance.CreatBullet(attackEffect01,jian.position);
        return attckEffect;
    }

    public void RemoveAttackEffect01()
    {
        Pool.instance.Destroys(attckEffect);
    }
}
