﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIController : MonoBehaviour
{
    public static UIController instance;

    private GameObject AllUILianQi;
    private Transform trans;
    public GameObject backUI;
    public GameObject WinUI;
    private GameObject allUILianQi;
    public AudioSource winSound;
    private GameObject AllWinUI;
    private GameObject allWinUI;
    
    private void Start()
    {
        instance = this;
        GameObject gameObject = this.gameObject;
        AllUILianQi = Resources.Load<GameObject>("Prefabs/AllUI");
        trans = this.GetComponentInParent<Transform>();
        AllWinUI= Resources.Load<GameObject>("Prefabs/WinUI");
    }
    public void OpenActiveAndCreateNewUI()
    {
        gameObject.SetActive(false);
        backUI.SetActive(true);
        allUILianQi= Pool.instance.CreatBullet(AllUILianQi, trans.position);
        //allUILianQi = GameObjectPool.instance.GetPool(AllUILianQi, trans.position);

        
    }
    public void CloseActiveAndDellteNewUI()
    {
        gameObject.SetActive(true);
        backUI.SetActive(false);
        Pool.instance.Destroys(allUILianQi);
        allUILianQi.SetActive(false);
        //GameObjectPool.instance.IntoPool(AllUILianQi);
    }

    public void OpenAndCreateWinUI()
    {
        allWinUI= Pool.instance.CreatBullet(AllWinUI, trans.position);
        //winSound.Play();
    }
    
    public void CloseAndDeleteWinUI()
    {
        Pool.instance.Destroys(allWinUI);
    }

    public void CloseWinUI()
    {
        WinUI.SetActive(false);    
    }
}
