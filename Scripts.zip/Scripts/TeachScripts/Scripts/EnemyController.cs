﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public int health;

    public float x;
    public float z;
    public float y;

    private Transform PlayerTransform;
    private Vector3 position;
    private GameObject EnemySelf;
    void Start()
    {
        x = Random.Range(-3, 3);
        y = Random.Range(0, 0.5f);
        z = Random.Range(-3, 3);

        PlayerTransform = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        EnemySelf = GameObject.FindGameObjectWithTag("Enemy");
        health = 100;
    }

    private void Update()
    {
        position = PlayerTransform.position + new Vector3(x, y, z);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Player")
        {
            GameObjectCreateController.instance.AddGameObject(EnemySelf, position);
        }
    }

}
