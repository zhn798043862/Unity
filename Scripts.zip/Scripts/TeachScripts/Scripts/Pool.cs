﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pool : MonoBehaviour
{
    public static Pool instance;
    public Queue<GameObject> goQueue = new Queue<GameObject>();//创建一个队列（先进先出）
    private void Start()
    {
        instance = this;
    }
    //创建子弹
    public GameObject CreatBullet(GameObject go,Vector3 position)
    {
        GameObject rongqi; //你用来取物体的容器； 

        if (goQueue.Count > 0)//判断队列里有没有元素
        {//出队列
            rongqi = goQueue.Dequeue();
        }
        else//队列里面有已经用过的物体
        {
            rongqi = Instantiate(go, position, Quaternion.identity) as GameObject;
            goQueue.Enqueue(rongqi);
        }
        rongqi.SetActive(true);//激活游戏物体

        return rongqi;
    }
    public void Destroys(GameObject go)
    {
        goQueue.Enqueue(go);//入队列
        go.SetActive(false);//禁用游戏物体
    }
}
