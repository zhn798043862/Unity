﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour,AllAnimation
{
    

    public float moveSpeed = 6f;

    public float rotateSpeed = 10f;

    public float jumpSpeed = 8.0F;

    public float gravity = 20.0F;

    private Animator _animation;

    void Start()
    {
        _animation = GameObject.FindGameObjectWithTag("Player").GetComponent<Animator>();
       

    }

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        float translation = v * moveSpeed * Time.deltaTime;
        float rotation = h * rotateSpeed * Time.deltaTime;
        Vector3 movement = new Vector3(h, 0.0f, v);


        Move(h,v);
        RotateHorizontal();
        PlayerAttack();

        
        

    }

    public void Move(float horizontal, float vertical)
    {
        float translation = vertical * moveSpeed * Time.deltaTime;
        float rotation = horizontal * rotateSpeed * Time.deltaTime;

        
            if (Mathf.Abs(horizontal) > 0 || Mathf.Abs(vertical) > 0)
            {
                

                _animation.SetBool("IsWalk", true);

                       
            }
            else
            {
                StandAndRelax();
             }
        if (Mathf.Abs(vertical) > 0)
        {
            //transform.position = transform.position + moveSpeed * new Vector3(0, 0, translation) * Time.deltaTime;
        }
        this.transform.Translate(translation * Vector3.forward);

        this.transform.Rotate(rotation * Vector3.up);



    }
    public void RotateHorizontal()
    {
        if (transform.localEulerAngles.y != 0)
        {
            float roty = transform.localEulerAngles.y;
            transform.localEulerAngles = new Vector3(0, roty, 0);
        }
        
    }
    public void StandAndRelax()
    {
        float timer = 10.0f;    
            _animation.SetBool("IsWalk", false);


        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            //_animation.SetTrigger("relax");
            timer = 10.0f;
        }
    }


    public void PlayerAttack()
    {
        if (Input.GetMouseButtonDown(0))
        {
            _animation.SetBool("IsAttack01", true);
        }
        else
        {
            _animation.SetBool("IsAttack01", false);

        }
    }


}
