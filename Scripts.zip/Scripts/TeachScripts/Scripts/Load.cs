﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Load : MonoBehaviour {
    public Slider slider;//放置进度条
    public float value;//定义异步加载进度值
    private AsyncOperation ao;//定义异步加载对象
	// Use this for initialization
	void Start () {
        value = 0f;
        if (SceneManager.GetActiveScene().name == "Loading")
        {
            StartCoroutine(Loads());//启动携程
        }
	}
	IEnumerator Loads()
    {
        ao = SceneManager.LoadSceneAsync("gamePlaying");
        ao.allowSceneActivation = false;//阻止场景自动跳转
        yield return(0);
    }
	// Update is called once per frame
	void Update () {
        value = ao.progress;//把异步加载的进度给value
        if (ao.progress >= 0.9f)//我们的加载资源进度只能到0.9f；
            value = 1f;
        if(value!=slider.value)//差值运算，让滑动条的变化更加平滑
        {
            slider.value = Mathf.Lerp(slider.value, value, Time.deltaTime * 2);
            if (value - slider.value <= 0.01f)
            {
                slider.value = value;
            }
            if (slider.value == 1)
                ao.allowSceneActivation = true;
        }
	}
}
