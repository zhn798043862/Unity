﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewPlayerController : MonoBehaviour
{
    public Animator animator;
    Vector3 direction;
    private int speedRotate = Animator.StringToHash("SpeedRotate");
    private int speedZ = Animator.StringToHash("SpeedZ");
    public float speed;
    public float rotateSpeed;
    public float jumpSpeed;
    private Transform groundTrans;
    private AudioSource ads;
    private AudioClip walkSound;  //指定需要播放的音效
    public AudioClip attackSound; //指定攻击音效
    private GameObject attackEffect01;
    private int EnemyCount = 0;
    private Vector3 movement;
    public GameObject WinUI;
    public AudioSource winSound;
    private int attackEffectCount = 0;
    public GameObject tishi;
    private Transform playertrans;
    private void Awake()
    {
        groundTrans = GameObject.FindGameObjectWithTag("Ground").GetComponent<Transform>();
        playertrans = this.transform;
        //walkSound = Resources.Load<AudioClip>("90");
        ads = GameObject.FindGameObjectWithTag("WalkSound").GetComponent<AudioSource>();
        ads.playOnAwake = false;
        attackEffect01 = Resources.Load<GameObject>("SpecialEffects/OrdosFX/Magic Slashes FX/Prefabs/EffectPrefabs/Eff1_Crack");

    }
    private void Update()
    {
        //StartCoroutine(PlayWalkSound());
        //ads.PlayOneShot(walkSound);
    }

    private void FixedUpdate()
    {
        if (transform.localEulerAngles.y != 0)
        {
            float roty = transform.localEulerAngles.y;
            transform.localEulerAngles = new Vector3(0, roty, 0);
        }

        if (Input.GetMouseButtonDown(0))
        {
            animator.SetBool("IsAttack01", true);
            animator.SetBool("IsRun", false);
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("ShortAttack_01"))
            {
                //GameObject attack = EffectCreateController.instance.AddAttackEffect01();
                attackEffectCount++;               
            }
            if (attackEffectCount != 0)
            {
                //EffectCreateController.instance.RemoveAttackEffect01();
            }
        }
        else
        {
            animator.SetBool("IsAttack01", false);

        }
        animator.SetFloat(speedZ, Input.GetAxis("Vertical"));

        animator.SetFloat(speedRotate, Input.GetAxis("Horizontal"));

        if (Input.GetKeyDown(KeyCode.Space))
        {

            if (this.transform.position.y<=playertrans.position.y+10.5f)
            {
                //GetComponent<Rigidbody>().velocity += new Vector3(0, 2, 0);
                GetComponent<Rigidbody>().AddForce(Vector3.up * jumpSpeed);
                animator.SetBool("IsJump", true);
                animator.SetBool("IsRun", false);
            }
            
        }
        else
        {
            animator.SetBool("IsJump", false);
        }
        movement = new Vector3(Input.GetAxis("Horizontal"), 0.0f, Input.GetAxis("Vertical"));
        if (movement.sqrMagnitude > 0)
        {
            animator.SetBool("IsRun", true);
            direction = movement;
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("Idle_nonWeapon 0"))
            {
                

                this.transform.Translate(Input.GetAxis("Vertical") * speed * Time.deltaTime * Vector3.forward);

                this.transform.Rotate(Input.GetAxis("Horizontal") * rotateSpeed * Time.deltaTime * Vector3.up);
            }
        }
        else
        {
            animator.SetBool("IsRun", false);
            movement = direction;
            ads.Stop();
            this.transform.Translate(Input.GetAxis("Vertical") * speed * Time.deltaTime * Vector3.zero);

            this.transform.Rotate(Input.GetAxis("Horizontal") * rotateSpeed * Time.deltaTime * Vector3.zero);
        }
    }
    private IEnumerator PlayWalkSound()
    {
        
        ads.PlayOneShot(walkSound);
        yield  break;
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Enemy")
        {
            Destroy(collision.collider.gameObject);
            EnemyCount++;
            if (EnemyCount == 3)
            {

                //UIController.instance.OpenAndCreateWinUI();
                WinUI.SetActive(true);
                winSound.Play();
                tishi.SetActive(false);
            }
        }

        if (collision.collider.tag == "Ground"&& movement.sqrMagnitude > 0)
        {
            StartCoroutine(PlayWalkSound());
        }
    }
}
