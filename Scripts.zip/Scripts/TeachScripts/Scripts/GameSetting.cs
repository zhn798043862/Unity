﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor;
using UnityEngine.UI;

public class GameSetting : MonoBehaviour {
    public AudioSource aud;
    public GameObject obj;
    public void audioChanged()
    {
        aud.volume = obj.GetComponent<Slider>().value;
        //aud.volume = UIProgressBar.current.value;
    }
    public void exitGame()
    {
        //UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }
    public void startGame()
    {
        Invoke("jiazai", 2.0f); 
    }
    private void jiazai()
    {
        SceneManager.LoadScene(1);
    }
}
