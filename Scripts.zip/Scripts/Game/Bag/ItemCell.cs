﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 道具格子对象
/// </summary>
public class ItemCell : BasePanel
{
    private ItemInfo itemInfo;
    //根据道具信息 初始化 格子信息
    public void InitInfo(ItemInfo info)
    {
        this.itemInfo = info;
        //根据道具信息的数据 来更新格子对象
        Item itemDate = GameDataMgr.GetInstance().GetItemInfo(info.id);
        //使用我们的道具表里的数据
        
        //图标
        //通过 道具ID得到的 道具表中的 数据信息 就可以得到就行的道具ID 用的图标室什么 加载他来用 即可
        GetControl<Image>("imgIcon").sprite =ResMgr .GetInstance ().Load <Sprite>("Icon/"+itemDate .icon );
        //数量
        GetControl<Text>("txtNum").text = info.num.ToString();
    }
}
