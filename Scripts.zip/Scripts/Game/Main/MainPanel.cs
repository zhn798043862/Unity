﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainPanel : BasePanel 
{
    // Start is called before the first frame update
    void Start()
    {
        GetControl<Button>("btnRole").onClick.AddListener(() =>
     {
         UIManager.GetInstance().ShowPanel<BagPanel>("BagPanel");
     }
            );

        ShowMe();
    }

    public override void ShowMe()
    {
        base.ShowMe();
        //更新名字 等级 钱等基础信息
        GetControl<Text>("txtName").text = GameDataMgr.GetInstance().playerInfo.name;
        GetControl<Text>("txtLev").text = GameDataMgr.GetInstance().playerInfo.lev.ToString ();
        GetControl<Text>("txtMoney").text = GameDataMgr.GetInstance().playerInfo.money .ToString ();
        GetControl<Text>("txtGem").text = GameDataMgr.GetInstance().playerInfo.gem.ToString ();
        GetControl<Text>("txtPro").text = GameDataMgr.GetInstance().playerInfo.pro .ToString ();
        
    }
}
