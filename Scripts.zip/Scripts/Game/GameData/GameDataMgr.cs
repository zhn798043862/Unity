﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

public class GameDataMgr : BaseManager <GameDataMgr >
{

    private Dictionary<int, Item> itemInfos = new Dictionary<int, Item>();

    public Player playerInfo;

    //玩家信息存储路径
    private static string PlayerInfo_Url = Application.persistentDataPath + "/PlayerInfo.txt";
    /// <summary>
    /// 初始化数据
    /// </summary>
   public void Init()
    {
        //加载Resources文件夹下的json文件 获取它的内容
        string info = ResMgr.GetInstance().Load<TextAsset>("Json/ItemInfo").text;
        Debug.Log(info);
        //根据json文件的内容 接续成对应的数据结构 并储存起来
        Items items = JsonUtility.FromJson<Items>(info);
        Debug.Log(items.info.Count);
        for(int i=0;i<items .info.Count; ++i)
        {
            itemInfos.Add(items.info[i].id, items.info[i]);
        }


        //初始化 角色信息
        if(File .Exists (PlayerInfo_Url))
        {
            //读出指定路径的文件的字节数据
            byte [] bytes = File.ReadAllBytes(PlayerInfo_Url);
            //吧字节数组转换成字符串
            string json = Encoding.UTF8.GetString(bytes);
            //再把字符串转成玩家的数据结构
            playerInfo = JsonUtility.FromJson<Player>(json);
            Debug.Log(PlayerInfo_Url);
            Debug.Log(playerInfo.name );
        }else
        {
            //没有玩家数据时 初始化一个数据
            playerInfo = new Player();
            //并且存储他 
            SavePlayerInfo();

        }
    }
    /// <summary>
    /// 保存玩家信息
    /// </summary>
    public void SavePlayerInfo()
    {
        //并且存储他     
        string json = JsonUtility.ToJson(playerInfo);
        File.WriteAllBytes(PlayerInfo_Url, Encoding.UTF8.GetBytes(json));
    }
    /// <summary>
    /// 根据道具id 得到道具的详细信息
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Item GetItemInfo(int id)
    {
        if (itemInfos.ContainsKey(id))
            return itemInfos[id];
        return null;
    }
}


public class Player
{
    public string name;
    public int lev;
    public int money;
    public int gem;
    public int pro;
    public List<ItemInfo> items;
    public List<ItemInfo> equips;
    public List<ItemInfo> gems;

    public Player()
    {
        name = "神龙大侠";
        lev = 1;
        money = 9999;
        gem = 0;
        pro = 99;
        items = new List<ItemInfo>() { new ItemInfo() { id = 1, num = 1 } };
        equips = new List<ItemInfo>() { new ItemInfo (){id = 3, num = 10 } };
        gems = new List<ItemInfo>();
    }
}
/// <summary>
/// 玩家拥有的道具基础信息
/// </summary>
public class ItemInfo
{
    public int id;
    public int num;
}

/// <summary>
/// 临时结构体 用来标识 道具表信息的数据结构
/// </summary>


public class Items
{
    public List<Item> info;
}
/// <summary>
/// 玩家拥有的道具基础信息
/// </summary>
[System .Serializable ]
public class Item
{
    public int id;
    public string name;
    public string  icon;
    public int type;
    public int price;
    public string tips;
}
